# Vimu Cinema Hub 2.0 — Plex 风格海报影音库 + Vimu 独立播放

**Android 双 APK、完全独立于 Kodi、Plex、DLNA。**

- 手机端 `Vimu Cinema Hub`：Fold6 本地 WebView UI（无外部网页/CDN），电影海报墙、首页精选、电影/剧集、搜索、收藏、最近观看、文件夹浏览、详情、视频大小、画质文件名标签、续播、指定分钟起播、文件夹播放列表与底部迷你控制台。
- Google TV 端 `Vimu Direct TV Bridge`：SMB2/3 直接读取共享硬盘，通过 TV 本机仅环回的 HTTP Range 代理把视频送给本机已安装的 Vimu；支持 Intent `forcename`、`forceresume`、`startfrom`、`forcedsrt` 和官方文件列表 API。
- TV 桥接端新增 SMB 多级扫描 `/api/library`（默认深度 5，至多 140 文件夹，600 视频）、可选 Android MediaSession 控制、可选播放退出结果保存（若 Vimu 返回播放结果）。

## 可用/条件性功能

| 功能 | 情况 |
| --- | --- |
| SMB 目录、电影海报墙、搜索、分类、收藏 | 支持；电影封面使用同名 jpg/png/webp、poster.jpg、folder.jpg；**不包含在线自动刮削** |
| 手机选片 → TV Vimu 打开 | 使用官方 Intent；后台启动可能被 Android TV 阻止，可在电视端打开 Bridge 点“播放待处理影片” |
| 单集播放与文件夹连播 | 使用 Vimu 官方影片 / Playlist Intent；需实机检验 Vimu 当前版本 |
| 指定分钟起播 / 续播 | Intent `startfrom`；若 Vimu 退出后返回进度，桥接端记录断点；播放器不返回就无法保证同步 |
| 暂停、上一部、下一部、±30 秒、拖动进度条 | **有条件**：Vimu 提供可控制的 Android MediaSession，且在 TV 桥接端授予通知使用权时才启用；若 Vimu 不提供，会显示灰色禁用 |
| 测试 Android 系统媒体播放/暂停键 | 已加入测试按钮，只有 Vimu 注册为系统媒体按键接收器时才有效，不保证执行 |
| TV 设备系统音量 +/− | 仅适用于 Android 可变音量输出；固定音量、ARC/eARC 声吧请用电视或 S61B 遥控器 |
| 音轨选择、字幕切换 | Vimu 自身菜单控制，**没有公开对应远程 API** |

## 通信架构

```text
Fold6「Vimu Cinema Hub」
    ↓  家庭 LAN HTTP :8765，16 位配对密钥
Google TV「Vimu Direct TV Bridge」
    ├── SMB2/SMB3 读取共享硬盘（JCIFS-NG）
    ├── 本机 127.0.0.1:8766 HTTP Range 视频流
    ├── 官方 Android Intent → Vimu (net.gtvbox.videoplayer / net.gtvbox.vimuhd)
    └── 可选 MediaSession / 播放结束结果
```

**视频流不经手机中转。** 只使用已安装的 Vimu 进行实际解码和 HDR、音频输出。

## 安装与测试

1. 从源码用 GitHub Actions 编译两个 debug APK。TV `tvbridge-debug.apk`、Fold6 `mobile-debug.apk`。
2. 电视先安装 Vimu（购买的正式版或官方 demo），再安装 `tvbridge-debug.apk`。
3. 电视打开 Bridge，点击 `启动电视桥接服务`，记录 TV IP 和页面显示的 16 位配对码。
4. 手机安装 `mobile-debug.apk`，右上角齿轮设置 TV IP + 配对码并连接。
5. 手机设置 SMB 服务器 IP、共享名称、用户名和密码，保存到电视，刷新影音库。
6. 手机点击海报 → 电视播放；如系统未自动切换 Vimu，返回 TV Bridge 点 `播放手机发来的待处理影片` 或打开待播通知。
7. 要试用播放控制：在电视 Bridge 点击 `授权媒体会话控制`，进入 Android 的通知使用权设置，允许 `Vimu Direct 媒体控制授权`。**如果 Vimu 未公布 Android MediaSession，即使授权也无法远程暂停/拖动。**
8. 要试用续播：从手机点某部电影，退出 Vimu，让桥接端获得 Activity Result；手机刷新资料库。如果 Vimu 不返回 `position/duration`，无法生成断点。

## 单 ZIP 上传 GitHub

1. 创建新的空 GitHub 仓库，例如 `VimuCinemaHub`：https://github.com/new
2. 在仓库根目录直接上传 **`VimuCinemaHub_v2_Source.zip`**（不用解压）。
3. 另新建 `.github/workflows/build-from-zip.yml`，粘贴同时提供的 `VimuCinemaHub_v2_build-from-zip.yml` 全文。
4. GitHub `Actions` → `Build Vimu Cinema Hub v2 from ZIP` → `Run workflow`。
5. 构建成功后从该 workflow 的 `Artifacts` 下载两份 APK 压缩包，解压后安装。

或解压源代码在项目根目录直接运行：

```bash
gradle :tvbridge:assembleDebug :mobile:assembleDebug --no-daemon
```

### 项目目录

- `mobile/src/main/assets/cinema.html`：纯离线深色影音 UI，带动态海报、弹层和遥控面板。
- `mobile/.../MainActivity.java`：Android WebView 和安全限定的本地 HTTP 请求代理。
- `tvbridge/.../SmbRepository.java`：SMB2/3、文件夹、海报、断点、递归有限扫描。
- `tvbridge/.../BridgeHttpServer.java`：带密钥的 JSON API 和 TV 本机 Range 流。
- `tvbridge/.../BridgeService.java`、`PlayerLauncherActivity.java`：Vimu 官方 Intent 和退出结果。
- `tvbridge/.../MediaRemote.java`、`SessionListener.java`：可选 Android MediaSession 控制。

## 局限与安全

- **没有实机确认 Vimu MediaSession 的存在。** Android Session 的暂停/快进能力是可选的，绝不是 Vimu 官方 API 已保证的功能。
- 不提供从公开网络访问：控制端口是未加密 HTTP，虽然要求 16 位密钥，SMB 密码传递时也没有 TLS 加密；**仅限可信家庭局域网**。建议路由器建立仅读取影视的 SMB 账户。
- TV 上保存 SMB 密码的 Android SharedPreferences 未额外加密；手机不会保存 SMB 密码。
- SMB 扫描设限以免路由器负载过高；大量影片分层文件夹仍可以用“文件夹”页面单独打开。
- 兼容性以 Google TV Streamer 4K 和 Vimu 当前版本的实测为准；已完成 JS 语法校验，但此运行环境没有 Android SDK/Gradle，**未完成 APK 编译、安装或播放验证**。
- 本工具不包含电影、海报版权资源，也不从外部自动抓取海报。

Vimu 官方 API：https://vimu.tv/player-api/

第三方：JCIFS-NG `eu.agno3.jcifs:jcifs-ng:2.1.10`，请遵守其对应 LGPL 许可。
