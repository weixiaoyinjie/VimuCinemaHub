package com.vimudirect.tv;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/** Foreground proxy activity is required for startActivityForResult() playback positions. */
public final class PlayerLauncherActivity extends Activity {
    private static final int REQUEST_PLAY = 390;
    private boolean started;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) { started = state.getBoolean("started", false); if (started) return; }
        BridgeService service = BridgeService.instance;
        if (service == null || service.getPrepared() == null) {
            Toast.makeText(this, "请先启动桥接服务并从手机选择影片", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        try {
            Intent vimu = service.vimuIntent(service.getPrepared());
            started = true;
            startActivityForResult(vimu, REQUEST_PLAY);
            service.setStatus("已启动 Vimu 播放 Activity（播放结果待返回）");
        } catch (Exception ex) {
            service.setStatus("无法启动 Vimu：" + ex.getMessage());
            finish();
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) { out.putBoolean("started", started); super.onSaveInstanceState(out); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PLAY) {
            BridgeService service = BridgeService.instance;
            if (service != null) service.storePlaybackResult(resultCode, data);
            finish();
        }
    }
}
