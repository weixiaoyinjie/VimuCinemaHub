package com.vimudirect.tv;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import org.json.JSONObject;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Locale;

public final class BridgeService extends Service {
    private static final String CHANNEL = "vimu_direct_bridge";
    static volatile BridgeService instance;
    static volatile WeakReference<MainActivity> visibleActivity = new WeakReference<>(null);
    private volatile String status = "尚未运行";
    private BridgeHttpServer server;
    private PendingPlay pending;
    private volatile String lastPath = "";
    private final Object lock = new Object();

    static final class PendingPlay {
        final ArrayList<String> paths;
        final int startMs;
        final String title;
        PendingPlay(ArrayList<String> paths, int startMs, String title) {
            this.paths = paths; this.startMs = startMs; this.title = title;
        }
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();
        startForeground(101, notification("电视桥接服务正在运行", false));
        new Thread(() -> {
            try {
                server = new BridgeHttpServer(this);
                server.start();
                setStatus("服务已启动；等待手机连接");
            } catch (Exception ex) { setStatus("启动失败: " + ex.getMessage()); }
        }, "vimu-server-start").start();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        if (server != null) server.stop();
        instance = null;
        super.onDestroy();
    }

    static String token(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("bridge", MODE_PRIVATE);
        String v = p.getString("token", "");
        if (!v.isEmpty()) return v;
        final String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom random = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 16; i++) b.append(alphabet.charAt(random.nextInt(alphabet.length())));
        v = b.toString();
        p.edit().putString("token", v).commit();
        return v;
    }

    boolean authorized(String provided) {
        if (provided == null) return false;
        byte[] expected = token(this).getBytes(StandardCharsets.UTF_8);
        byte[] actual = provided.trim().toUpperCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(expected, actual);
    }

    String getStatus() { return status; }
    void setStatus(String s) {
        status = s;
        MainActivity a = visibleActivity.get();
        if (a != null) a.runOnUiThread(a::refresh);
    }
    String getPendingTitle() { synchronized (lock) { return pending == null ? "" : pending.title; } }
    String getLastPath() { return lastPath; }
    void storePlaybackResult(int code, Intent data) {
        PendingPlay p;
        synchronized (lock) { p = pending; }
        if (p == null || p.paths.isEmpty()) return;
        String path = p.paths.get(0);
        if (data != null && data.hasExtra("url")) {
            try {
                Uri u = Uri.parse(data.getStringExtra("url"));
                String candidate = u.getQueryParameter("path");
                if (candidate != null && p.paths.contains(candidate)) path = candidate;
            } catch (Exception ignored) {}
        }
        if (code == 0 && data != null) {
            long pos = Math.max(0, data.getLongExtra("position", data.getIntExtra("position", 0)));
            long duration = Math.max(0, data.getLongExtra("duration", data.getIntExtra("duration", 0)));
            if (pos > 0 && (duration <= 0 || pos < duration - 20000)) {
                getSharedPreferences("resume", MODE_PRIVATE).edit()
                    .putLong("p:" + path, pos).putLong("d:" + path, duration).apply();
            }
            setStatus("Vimu 已退出播放；已记录断点：" + pos / 1000 + "秒");
        } else if (code == 1) {
            getSharedPreferences("resume", MODE_PRIVATE).edit().remove("p:" + path).remove("d:" + path).apply();
            setStatus("影片正常播放结束");
        } else if (code == 4) { setStatus("Vimu 报告播放失败"); }
        else { setStatus("Vimu 播放界面已关闭（未返回断点）"); }
    }

    int prepare(String path, boolean folder, int startMs) throws Exception {
        SmbRepository repo = new SmbRepository(this);
        ArrayList<String> files = folder ? repo.videoPaths(path) : new ArrayList<>();
        if (!folder) files.add(path);
        // Vimu official playlist API: array list of names and HTTP URLs.
        synchronized (lock) {
            pending = new PendingPlay(files, startMs, folder ? "播放文件夹：" + path : path.substring(path.lastIndexOf('/') + 1));
            lastPath = files.size() > 0 ? files.get(0) : "";
        }
        setStatus("收到播放请求：" + getPendingTitle());
        return files.size();
    }

    private String streamUrl(String path) {
        return "http://127.0.0.1:" + BridgeHttpServer.STREAM_PORT + "/stream?token="
                + Uri.encode(token(this)) + "&path=" + Uri.encode(path);
    }

    Intent vimuIntent(PendingPlay p) throws Exception {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setPackage(resolveVimuPackage());
        // Keep activity-for-result in the same task.
        if (p.paths.size() == 1) {
            String path = p.paths.get(0);
            i.setDataAndType(Uri.parse(streamUrl(path)), "video/*");
            i.putExtra("forcename", p.title);
            i.putExtra("forceresume", true);
            if (p.startMs > 0) i.putExtra("startfrom", p.startMs);
            String srt = new SmbRepository(this).optionalSrt(path);
            if (srt != null) i.putExtra("forcedsrt", streamUrl(srt));
        } else {
            ArrayList<String> names = new ArrayList<>();
            ArrayList<String> urls = new ArrayList<>();
            for (String path : p.paths) {
                names.add(path.substring(path.lastIndexOf('/') + 1));
                urls.add(streamUrl(path));
            }
            i.setDataAndType(Uri.parse("http://127.0.0.1:8766/playlist"), "application/vnd.gtvbox.filelist");
            i.putStringArrayListExtra("asusfilelist", urls);
            i.putStringArrayListExtra("asusnamelist", names);
        }
        return i;
    }

    private String resolveVimuPackage() {
        for (String pkg : new String[]{"net.gtvbox.videoplayer", "net.gtvbox.vimuhd"}) {
            try { if (getPackageManager().getPackageInfo(pkg, 0) != null) return pkg; }
            catch (Exception ignored) {}
        }
        return "net.gtvbox.videoplayer";
    }

    void requestLaunch() {
        PendingPlay current;
        synchronized (lock) { current = pending; }
        if (current == null || current.paths.isEmpty()) return;
        MainActivity a = visibleActivity.get();
        if (a != null && a.isActuallyVisible()) {
            a.runOnUiThread(this::launchPending);
        } else {
            // Android 10+ may suppress background activity launches, even with a foreground service.
            // Send a user-visible notification and attempt launch; never claim playback confirmation.
            showPendingNotification(current.title);
            try { startActivity(new Intent(this, PlayerLauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); setStatus("已尝试打开 Vimu 启动页（可能被系统限制）"); }
            catch (Exception e) { setStatus("请在电视桥接应用点击播放：" + e.getMessage()); }
        }
    }

    void launchPending() {
        PendingPlay current;
        synchronized (lock) { current = pending; }
        if (current == null || current.paths.isEmpty()) { setStatus("没有待处理影片"); return; }
        try {
            Intent i = new Intent(this, PlayerLauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            setStatus("已向 Vimu 发送播放 Intent（未获得实际播放确认）");
        } catch (Exception e) {
            setStatus("无法启动 Vimu：" + e.getMessage());
        }
    }

    PendingPlay getPrepared() { synchronized(lock) { return pending; } }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Vimu 局域网桥接", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("手机远程选择播放影片与必要的启动提示");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification notification(String text, boolean pending) {
        Intent open = new Intent(this, MainActivity.class);
        if (pending) open.setAction("com.vimudirect.tv.PLAY_PENDING");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, pending ? 202 : 201, open, flags);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(pending ? "Vimu 待播放：点击打开" : "Vimu Direct Bridge")
                .setContentText(text).setContentIntent(pi).setOngoing(!pending).build();
    }
    private void showPendingNotification(String title) {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(102, notification(title, true));
    }
}
