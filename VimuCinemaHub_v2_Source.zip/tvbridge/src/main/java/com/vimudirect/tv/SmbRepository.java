package com.vimudirect.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbRandomAccessFile;

/** TV reads SMB directly; the phone does not proxy large 4K files. */
public final class SmbRepository {
    private final Context app;
    SmbRepository(Context context) { app = context.getApplicationContext(); }

    private SharedPreferences prefs() { return app.getSharedPreferences("smb", Context.MODE_PRIVATE); }

    JSONObject configSafe() throws Exception {
        JSONObject out = new JSONObject();
        SharedPreferences p = prefs();
        out.put("host", p.getString("host", ""));
        out.put("share", p.getString("share", ""));
        out.put("user", p.getString("user", ""));
        out.put("domain", p.getString("domain", ""));
        out.put("passwordSet", !p.getString("password", "").isEmpty());
        return out;
    }

    void saveConfig(JSONObject obj) throws Exception {
        String host = obj.optString("host", "").trim();
        String share = obj.optString("share", "").trim();
        if (!host.matches("[A-Za-z0-9.\\-:]+") || host.isEmpty())
            throw new IllegalArgumentException("SMB 主机须为 IP 或域名（不带 smb://）");
        if (share.isEmpty() || share.contains("/") || share.contains("\\") || share.equals(".."))
            throw new IllegalArgumentException("共享名必须是一个有效文件夹名");
        String user = obj.optString("user", "");
        String domain = obj.optString("domain", "");
        String password = obj.has("password") ? obj.optString("password", "") : prefs().getString("password", "");
        prefs().edit().putString("host", host).putString("share", share)
                .putString("user", user).putString("domain", domain)
                .putString("password", password).apply();
    }

    private CIFSContext context() throws Exception {
        Properties props = new Properties();
        props.setProperty("jcifs.smb.client.minVersion", "SMB202");
        props.setProperty("jcifs.smb.client.maxVersion", "SMB311");
        props.setProperty("jcifs.smb.client.responseTimeout", "15000");
        props.setProperty("jcifs.smb.client.connTimeout", "10000");
        CIFSContext base = new BaseContext(new PropertyConfiguration(props));
        SharedPreferences p = prefs();
        return base.withCredentials(new NtlmPasswordAuthenticator(
                p.getString("domain", ""), p.getString("user", ""), p.getString("password", "")));
    }

    /** No ../, slash injection, share escape, or absolute paths. */
    static String safeRelative(String input) {
        if (input == null) throw new IllegalArgumentException("路径为空");
        String path = input.replace('\\', '/');
        while (path.startsWith("/")) path = path.substring(1);
        StringBuilder result = new StringBuilder();
        for (String part : path.split("/")) {
            if (part.isEmpty()) continue;
            if (part.equals(".") || part.equals("..") || part.indexOf(':') >= 0 || part.indexOf('\0') >= 0)
                throw new IllegalArgumentException("无效文件路径");
            if (result.length() > 0) result.append('/');
            result.append(part);
        }
        if (result.length() > 2048) throw new IllegalArgumentException("路径过长");
        return result.toString();
    }

    private SmbFile file(String relative) throws Exception { return file(relative, false); }

    private SmbFile file(String relative, boolean directory) throws Exception {
        SharedPreferences p = prefs();
        String host = p.getString("host", "");
        String share = p.getString("share", "");
        if (host.isEmpty() || share.isEmpty()) throw new IllegalStateException("请先设置 SMB 服务器");
        String path = safeRelative(relative);
        StringBuilder url = new StringBuilder("smb://").append(host).append('/').append(Uri.encode(share)).append('/');
        if (!path.isEmpty()) {
            for (String part : path.split("/")) url.append(Uri.encode(part)).append('/');
            url.setLength(url.length() - 1);
        }
        if (directory && url.charAt(url.length() - 1) != '/') url.append('/');
        return new SmbFile(url.toString(), context());
    }

    SmbFile open(String relative) throws Exception { return file(relative); }
    SmbRandomAccessFile randomAccess(String relative) throws Exception { return new SmbRandomAccessFile(file(relative), "r"); }

    static boolean video(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String ext : new String[]{".mkv", ".mp4", ".avi", ".mov", ".ts", ".m2ts", ".wmv", ".webm", ".mpg", ".mpeg", ".flv", ".m4v", ".vob"})
            if (n.endsWith(ext)) return true;
        return false;
    }
    static boolean image(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp");
    }
    static String parent(String path) {
        int p = path.lastIndexOf('/');
        return p < 0 ? "" : path.substring(0, p);
    }
    static String baseName(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? name : name.substring(0, dot);
    }

    JSONObject list(String path) throws Exception {
        String relative = safeRelative(path);
        SmbFile folder = file(relative, true);
        if (!folder.isDirectory()) throw new IllegalArgumentException("不是有效的文件夹");
        SmbFile[] files = folder.listFiles();
        Arrays.sort(files, Comparator.comparing(f -> f.getName().toLowerCase(Locale.ROOT)));
        Map<String, String> art = new HashMap<>();
        for (SmbFile f : files) {
            String n = f.getName();
            if (image(n)) art.put(n.toLowerCase(Locale.ROOT), n);
        }
        JSONArray items = new JSONArray();
        for (SmbFile f : files) {
            try {
                boolean dir = f.isDirectory();
                String name = f.getName().replaceAll("/$", "");
                if (!dir && !video(name)) continue;
                String filePath = (relative.isEmpty() ? "" : relative + "/") + name;
                JSONObject i = new JSONObject();
                i.put("name", name);
                i.put("path", filePath);
                i.put("dir", dir);
                if (!dir) {
                    i.put("size", f.length());
                    i.put("modified", f.lastModified());
                    android.content.SharedPreferences resume = app.getSharedPreferences("resume", Context.MODE_PRIVATE);
                    i.put("resumeMs", resume.getLong("p:" + filePath, 0));
                    i.put("durationMs", resume.getLong("d:" + filePath, 0));
                }
                String exact = art.get((baseName(name) + ".jpg").toLowerCase(Locale.ROOT));
                if (exact == null) exact = art.get((baseName(name) + ".jpeg").toLowerCase(Locale.ROOT));
                if (exact == null) exact = art.get((baseName(name) + ".png").toLowerCase(Locale.ROOT));
                if (exact == null) exact = art.get((baseName(name) + ".webp").toLowerCase(Locale.ROOT));
                if (exact == null) exact = art.get("poster.jpg");
                if (exact == null) exact = art.get("poster.png");
                if (exact == null) exact = art.get("folder.jpg");
                if (exact != null) i.put("art", (relative.isEmpty() ? "" : relative + "/") + exact);
                items.put(i);
            } catch (Exception ignored) { /* damaged file metadata should not hide whole folder */ }
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("path", relative);
        out.put("items", items);
        return out;
    }

    /** Bounded SMB tree scan for a single Plex-style poster library view. */
    JSONObject library(String root, int depth, int maxFiles) throws Exception {
        String base = safeRelative(root);
        int maxDepth = Math.max(0, Math.min(6, depth));
        int limit = Math.max(20, Math.min(800, maxFiles));
        JSONArray results = new JSONArray();
        ArrayDeque<String> q = new ArrayDeque<>();
        ArrayDeque<Integer> levels = new ArrayDeque<>();
        q.add(base); levels.add(0);
        int scanned = 0;
        int skipped = 0;
        JSONArray errors = new JSONArray();
        while (!q.isEmpty() && scanned < 140 && results.length() < limit) {
            String current = q.removeFirst();
            int level = levels.removeFirst();
            scanned++;
            try {
                JSONArray items = list(current).getJSONArray("items");
                for (int n = 0; n < items.length(); n++) {
                    JSONObject item = items.getJSONObject(n);
                    if (item.optBoolean("dir")) {
                        if (level < maxDepth && q.size() < 160) {
                            q.addLast(item.getString("path")); levels.addLast(level+1);
                        }
                    } else if (results.length() < limit) {
                        item.put("folder", current);
                        results.put(item);
                    }
                }
            } catch (Exception e) {
                skipped++;
                if (errors.length() < 4) errors.put((current.isEmpty()?"根目录":current) + " : " + e.getMessage());
            }
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("items", results);
        out.put("foldersScanned", scanned);
        out.put("failedFolders", skipped);
        out.put("errors", errors);
        out.put("partial", !q.isEmpty() || results.length() >= limit);
        return out;
    }

    ArrayList<String> videoPaths(String folder) throws Exception {
        JSONArray items = list(folder).getJSONArray("items");
        ArrayList<String> results = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) {
            JSONObject f = items.getJSONObject(i);
            if (!f.getBoolean("dir")) results.add(f.getString("path"));
        }
        return results;
    }

    String optionalSrt(String moviePath) throws Exception {
        String p = safeRelative(moviePath);
        String srt = parent(p);
        srt = (srt.isEmpty() ? "" : srt + "/") + baseName(p.substring(p.lastIndexOf('/') + 1)) + ".srt";
        return file(srt).exists() ? srt : null;
    }

    byte[] smallImage(String path) throws Exception {
        if (!image(path)) throw new IllegalArgumentException("仅允许读取图片");
        try (SmbFile f = file(path); InputStream in = f.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            if (f.length() > 3_000_000L) throw new IllegalArgumentException("封面超过3MB");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                if (bytes.size() + n > 3_000_000) throw new IllegalArgumentException("封面过大");
                bytes.write(buf, 0, n);
            }
            return bytes.toByteArray();
        }
    }
}
