package com.vimudirect.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.util.Base64;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/** Offline premium UI + native, authenticated LAN requests; no Kodi, Plex or DLNA dependency. */
public final class MainActivity extends Activity {
    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(6);
    private SharedPreferences settings() { return getSharedPreferences("mobile_v2", MODE_PRIVATE); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff07111e);
        getWindow().setNavigationBarColor(0xff070d16);
        web = new WebView(this);
        web.setBackgroundColor(0xff070d16);
        WebSettings w = web.getSettings();
        w.setJavaScriptEnabled(true);
        w.setDomStorageEnabled(true);
        w.setAllowFileAccess(true);
        w.setAllowFileAccessFromFileURLs(false);
        w.setAllowUniversalAccessFromFileURLs(false);
        w.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
        });
        web.addJavascriptInterface(new JsBridge(), "VimuNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/cinema.html");
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.uiBack && window.uiBack()", null);
    }
    @Override protected void onDestroy() {
        io.shutdownNow();
        web.removeJavascriptInterface("VimuNative");
        web.destroy();
        super.onDestroy();
    }
    private void deliver(String id, String result) {
        main.post(() -> {
            if (web != null) web.evaluateJavascript("window.nativeResult(" + JSONObject.quote(id) + "," + JSONObject.quote(result) + ")", null);
        });
    }
    private String apiRoot() throws Exception {
        String host = settings().getString("host", "").trim();
        if (!host.matches("[a-zA-Z0-9.\\-]+") || host.isEmpty() || host.length() > 253)
            throw new IllegalArgumentException("请输入有效的 Google TV IP，例如 192.168.0.79");
        return "http://" + host + ":8765";
    }
    private HttpURLConnection make(String endpoint, String method) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(apiRoot() + endpoint).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(9000);
        c.setReadTimeout(endpoint.startsWith("/api/library") ? 55000 : 18000);
        c.setRequestProperty("X-Bridge-Key", settings().getString("key", ""));
        c.setRequestProperty("Accept", "application/json");
        c.setUseCaches(false);
        return c;
    }
    private byte[] read(InputStream stream, int max) throws Exception {
        try (InputStream in = stream; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("电视没有返回数据");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) != -1) {
                if (out.size() + n > max) throw new IllegalArgumentException("响应过大");
                out.write(b, 0, n);
            }
            return out.toByteArray();
        }
    }
    private JSONObject transact(String path, String method, String body) throws Exception {
        if (!path.startsWith("/api/") || path.contains("\r") || path.contains("\n")) throw new IllegalArgumentException("非法 API 路径");
        HttpURLConnection c = make(path, method);
        try {
            if ("POST".equals(method)) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] data = body.getBytes(StandardCharsets.UTF_8);
                if (data.length > 15000) throw new IllegalArgumentException("请求过大");
                try (OutputStream out = c.getOutputStream()) { out.write(data); }
            }
            int status = c.getResponseCode();
            byte[] response = read(status < 400 ? c.getInputStream() : c.getErrorStream(), 8_000_000);
            JSONObject j = new JSONObject(new String(response, StandardCharsets.UTF_8));
            if (status >= 400) j.put("ok", false);
            return j;
        } finally { c.disconnect(); }
    }
    final class JsBridge {
        @JavascriptInterface public String preferences() {
            JSONObject j = new JSONObject();
            try {
                j.put("host", settings().getString("host", ""));
                j.put("key", settings().getString("key", ""));
                j.put("smbHost", settings().getString("smbHost", ""));
                j.put("smbShare", settings().getString("smbShare", ""));
                j.put("smbUser", settings().getString("smbUser", ""));
                j.put("favorites", settings().getString("favorites", "[]"));
                j.put("history", settings().getString("history", "[]"));
            } catch (Exception ignored) {}
            return j.toString();
        }
        @JavascriptInterface public void save(String data) {
            try {
                JSONObject v = new JSONObject(data);
                SharedPreferences.Editor e = settings().edit();
                for (String key : new String[]{"host","key","smbHost","smbShare","smbUser","favorites","history"})
                    if (v.has(key)) e.putString(key, v.optString(key));
                e.apply();
            } catch (Exception ignored) {}
        }
        @JavascriptInterface public void request(String id, String method, String path, String body) {
            io.execute(() -> {
                String result;
                try {
                    if (!("GET".equals(method) || "POST".equals(method))) throw new IllegalArgumentException("HTTP method rejected");
                    result = transact(path, method, body == null ? "{}" : body).toString();
                } catch (Exception ex) {
                    JSONObject error = new JSONObject();
                    try { error.put("ok", false).put("message", ex.getMessage() == null ? "连接失败" : ex.getMessage()); } catch(Exception ignored) {}
                    result = error.toString();
                }
                deliver(id, result);
            });
        }
        @JavascriptInterface public void art(String id, String path) {
            io.execute(() -> {
                String result;
                HttpURLConnection c = null;
                try {
                    c = make("/api/art?path=" + android.net.Uri.encode(path), "GET");
                    if (c.getResponseCode() != 200) throw new IllegalArgumentException("没有找到封面");
                    byte[] img = read(c.getInputStream(), 3_500_000);
                    String lower = path.toLowerCase(java.util.Locale.ROOT);
                    String mime = lower.endsWith(".png") ? "image/png" : lower.endsWith(".webp") ? "image/webp" : "image/jpeg";
                    result = new JSONObject().put("ok", true).put("src", "data:" + mime + ";base64," + Base64.encodeToString(img, Base64.NO_WRAP)).toString();
                } catch (Exception e) { result = "{\"ok\":false}"; }
                finally { if (c != null) c.disconnect(); }
                deliver(id, result);
            });
        }
    }
}
