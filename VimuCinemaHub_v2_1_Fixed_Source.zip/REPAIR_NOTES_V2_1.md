# Vimu Cinema Hub 2.1 — TV 播放链路修复版

## 本次修复

1. **删除 Android 主线程上的 SMB 操作**。旧版本 `BridgeService.vimuIntent()` 在启动 Vimu 前直接运行 `SmbRepository.optionalSrt()`；JCIFS 的网络调用可触发 `NetworkOnMainThreadException`，异常 `message` 有时是 null。2.1 不再在播放器启动期间查询 SMB 字幕。
2. **SMB 连接复用**。电视端在同一个桥接服务内部复用 `SmbRepository` 与 JCIFS `CIFSContext`，避免每打开一张封面或一部影片都创建新上下文。更换配置后刷新上下文。
3. **关闭 SMB 资源**。文件夹对象、`listFiles()` 返回的文件对象、单片验证和 HTTP Range 文件读取均在完成后关闭。网络读取出错时写入 Android 日志并在 TV 桥接状态显示异常类别。
4. **减轻路由器负担**。取消手机连接后自动扫描。电影/剧集海报库需手动点刷新（最多 40 文件夹 / 250 视频，默认深度 3）；文件夹浏览始终可以直接进入。自动排除 `$RECYCLE.BIN`、`.dmApp`、`.log`、`@eaDir` 等系统目录。
5. **明确启动错误**。检查 Vimu 包是否存在、是否有可响应 Intent 的 Activity；失败时显示实际异常类名，而不是 `null`。发送指令不等于播放已成功。
6. **优化本机视频流**。Range 请求重用一次 SMB 文件对象，打开并定位成功后再回送 HTTP 视频头。支持 GET/HEAD、单范围请求；出现读取异常保留诊断信息。

## 本轮刻意暂缓的功能

- 自动匹配外挂 SRT 字幕的 `forcedsrt` 暂时关闭，避免为排查播放失败再增加 SMB 请求；视频内嵌字幕仍可直接由 Vimu 处理。
- 继续保留现有手机电影/剧集/文件夹/收藏/详情/遥控界面，但**不承诺** Vimu 会暴露媒体会话、允许远程快进等。Vimu 官方 Intent API 不保证这些控制能力。
- 本机环境没有 Android SDK/Gradle，也没有你的 Google TV，已做静态修改和 JS/XML 检查，**仍需 GitHub Actions 编译和电视实机验证**。这是待测试修复版，不是已验证完美运行的 APK。

## 安装测试优先顺序

1. 将 ZIP 上传 GitHub 仓库根目录，创建 `.github/workflows/build-from-zip.yml`，内容用另附同名 YAML 文件，然后运行 GitHub Actions。
2. TV 安装 `tvbridge-debug.apk`，Fold6 安装 `mobile-debug.apk`。如果 Android 提示签名冲突，旧的 debug APK 需要卸载再安装，新安装可能清除配对码和 SMB 设置；卸载之前先记下 TV IP、共享主机及用户名，密码无需向他人提供。
3. 电视打开 Bridge，启动服务；Fold6 设置 TV IP + **电视当前显示**的 16 位配对码。
4. Fold6 到 **「文件夹」**，进入一个含视频的目录，点 **一部普通 MP4/MKV**，不要先点击“刷新影音库”。保持 TV Bridge 处于电视前台，以减少系统后台启动限制。
5. 若影片成功在 Vimu 播放，说明 Intent 和本机 Range 流已打通。随后测试手动扫描海报与其他功能。
6. 若仍不成功，拍下电视 Bridge 显示的**完整错误类别和文字**，以定位是播放器 Activity、SMB 认证、视频 Range 还是 Android 后台限制。

**安全**：配对码不能公开，控制端 HTTP 未使用 TLS，请勿将 8765 对公网开放；建议 SMB 使用只读账户。

API 依据：<https://vimu.tv/player-api/>。
