package com.vimudirect.tv;

import android.net.Uri;
import org.json.JSONObject;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbRandomAccessFile;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Private, token-authenticated LAN control plus TV-local HTTP Range video stream. */
final class BridgeHttpServer {
    static final int CONTROL_PORT = 8765;
    static final int STREAM_PORT = 8766;
    private final BridgeService service;
    private final SmbRepository smb;
    private final ExecutorService workers = Executors.newFixedThreadPool(10);
    private final AtomicBoolean active = new AtomicBoolean(false);
    private ServerSocket control;
    private ServerSocket stream;

    BridgeHttpServer(BridgeService service, SmbRepository repository) {
        this.service = service;
        this.smb = repository;
    }

    void start() throws Exception {
        control = new ServerSocket();
        control.setReuseAddress(true);
        control.bind(new InetSocketAddress("0.0.0.0", CONTROL_PORT));
        stream = new ServerSocket();
        stream.setReuseAddress(true);
        stream.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), STREAM_PORT));
        active.set(true);
        Thread controlLoop = new Thread(() -> accept(control, false), "vimu-control-listener");
        Thread streamLoop = new Thread(() -> accept(stream, true), "vimu-range-listener");
        controlLoop.start();
        streamLoop.start();
    }

    void stop() {
        active.set(false);
        try { if (control != null) control.close(); } catch (Exception ignored) {}
        try { if (stream != null) stream.close(); } catch (Exception ignored) {}
        workers.shutdownNow();
    }

    private void accept(ServerSocket listener, boolean video) {
        while (active.get()) {
            try {
                Socket client = listener.accept();
                workers.execute(() -> {
                    try (Socket s = client) {
                        s.setSoTimeout(video ? 30000 : 12000);
                        if (video) handleStream(s); else handleControl(s);
                    } catch (Exception ignored) {}
                });
            } catch (Exception ex) {
                if (active.get()) service.setStatus("网络服务错误：" + ex.getMessage());
            }
        }
    }

    private static class Request {
        String method, target;
        Map<String, String> headers = new HashMap<>();
        byte[] body = new byte[0];
    }

    private static String readLine(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        while (b.size() < 8192) {
            int c = in.read();
            if (c == -1) return b.size() == 0 ? null : b.toString("ISO-8859-1");
            if (c == '\n') break;
            if (c != '\r') b.write(c);
        }
        if (b.size() >= 8192) throw new IllegalArgumentException("HTTP request line too long");
        return b.toString("ISO-8859-1");
    }

    private Request read(Socket client) throws Exception {
        InputStream in = client.getInputStream();
        String line = readLine(in);
        if (line == null) return null;
        String[] first = line.split(" ");
        if (first.length < 2) throw new IllegalArgumentException("Invalid request");
        Request req = new Request();
        req.method = first[0];
        req.target = first[1];
        for (int count = 0; count < 60; count++) {
            line = readLine(in);
            if (line == null || line.isEmpty()) break;
            int colon = line.indexOf(':');
            if (colon > 0) req.headers.put(line.substring(0, colon).trim().toLowerCase(Locale.ROOT), line.substring(colon + 1).trim());
        }
        int len = Integer.parseInt(req.headers.getOrDefault("content-length", "0"));
        if (len < 0 || len > 16384) throw new IllegalArgumentException("Invalid body size");
        req.body = new byte[len];
        int pos = 0;
        while (pos < len) {
            int n = in.read(req.body, pos, len - pos);
            if (n < 0) throw new IllegalArgumentException("Incomplete body");
            pos += n;
        }
        return req;
    }

    private static void headers(OutputStream out, int code, String reason, String contentType, long bytes, String extra) throws Exception {
        String h = "HTTP/1.1 " + code + " " + reason + "\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + bytes + "\r\n"
                + "Connection: close\r\n"
                + "Cache-Control: no-store\r\n" + extra + "\r\n";
        out.write(h.getBytes(StandardCharsets.ISO_8859_1));
    }

    private static void send(Socket s, int code, String type, byte[] bytes) throws Exception {
        OutputStream out = s.getOutputStream();
        String status = code == 200 ? "OK" : code == 202 ? "Accepted" : code == 401 ? "Unauthorized"
                : code == 404 ? "Not Found" : code == 405 ? "Method Not Allowed" : "Error";
        headers(out, code, status, type, bytes.length, "");
        out.write(bytes);
        out.flush();
    }

    private static void json(Socket s, int code, JSONObject obj) throws Exception {
        send(s, code, "application/json; charset=utf-8", obj.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static JSONObject response(boolean ok, String message) throws Exception {
        return new JSONObject().put("ok", ok).put("message", message);
    }

    private void handleControl(Socket client) {
        try {
            Request req = read(client);
            if (req == null) return;
            Uri target = Uri.parse("http://localhost" + req.target);
            String route = target.getPath();
            if ("/api/ping".equals(route)) {
                json(client, 200, new JSONObject().put("ok", true).put("app", "Vimu Direct TV Bridge").put("version", "2.1"));
                return;
            }
            if (!service.authorized(req.headers.getOrDefault("x-bridge-key", ""))) {
                json(client, 401, response(false, "配对码错误"));
                return;
            }
            if ("/api/status".equals(route) && "GET".equals(req.method)) {
                JSONObject o = response(true, service.getStatus());
                o.put("config", smb.configSafe());
                o.put("pending", service.getPendingTitle());
                o.put("media", MediaRemote.state(service));
                o.put("lastPath", service.getLastPath());
                json(client, 200, o);
            } else if ("/api/media".equals(route) && "GET".equals(req.method)) {
                JSONObject media = MediaRemote.state(service);
                media.put("ok", true);
                media.put("pending", service.getPendingTitle());
                media.put("lastPath", service.getLastPath());
                json(client, 200, media);
            } else if ("/api/control".equals(route) && "POST".equals(req.method)) {
                JSONObject body = new JSONObject(new String(req.body, StandardCharsets.UTF_8));
                json(client, 200, MediaRemote.command(service, body.optString("action", ""), body.optLong("position", 0)));
            } else if ("/api/library".equals(route) && "GET".equals(req.method)) {
                String root = target.getQueryParameter("root");
                String depth = target.getQueryParameter("depth");
                String limit = target.getQueryParameter("limit");
                json(client, 200, smb.library(root == null ? "" : root,
                    depth == null ? 3 : Integer.parseInt(depth), limit == null ? 250 : Integer.parseInt(limit)));
            } else if ("/api/config".equals(route) && "POST".equals(req.method)) {
                smb.saveConfig(new JSONObject(new String(req.body, StandardCharsets.UTF_8)));
                json(client, 200, response(true, "已在电视端保存 SMB 设置"));
            } else if ("/api/config".equals(route) && "GET".equals(req.method)) {
                json(client, 200, new JSONObject().put("ok", true).put("config", smb.configSafe()));
            } else if ("/api/list".equals(route) && "GET".equals(req.method)) {
                json(client, 200, smb.list(target.getQueryParameter("path") == null ? "" : target.getQueryParameter("path")));
            } else if ("/api/art".equals(route) && "GET".equals(req.method)) {
                String path = target.getQueryParameter("path");
                String ext = path == null ? "" : path.toLowerCase(Locale.ROOT);
                String mime = ext.endsWith(".png") ? "image/png" : ext.endsWith(".webp") ? "image/webp" : "image/jpeg";
                send(client, 200, mime, smb.smallImage(path));
            } else if ("/api/play".equals(route) && "POST".equals(req.method)) {
                JSONObject p = new JSONObject(new String(req.body, StandardCharsets.UTF_8));
                boolean folder = p.optBoolean("folder", false);
                String path = SmbRepository.safeRelative(p.optString("path", ""));
                if (!folder) {
                    if (!SmbRepository.video(path)) throw new IllegalArgumentException("不支持的影片文件格式");
                    try (SmbFile targetFile = smb.open(path)) {
                        if (!targetFile.isFile()) throw new IllegalArgumentException("影片不存在或不是有效文件");
                    }
                }
                int start = p.optInt("startMs", -1);
                if (start < 0 && !folder) {
                    start = (int) Math.min(Integer.MAX_VALUE,
                        service.getSharedPreferences("resume", android.content.Context.MODE_PRIVATE).getLong("p:" + path, 0));
                }
                start = Math.max(0, start);
                int count = service.prepare(path, folder, start);
                if (count == 0) throw new IllegalArgumentException("没有找到可以播放的影片");
                service.requestLaunch();
                JSONObject o = response(true, "播放指令已发送；如果电视没有跳转，请在电视桥接App点击『播放待处理影片』");
                o.put("count", count);
                o.put("launch", "attempted_not_confirmed");
                json(client, 202, o);
            } else {
                json(client, 404, response(false, "未知接口"));
            }
        } catch (Exception e) {
            android.util.Log.e("VimuDirect", "Control endpoint failed", e);
            try { json(client, 400, response(false, BridgeService.explain(e))); } catch (Exception ignored) {}
        }
    }

    private static String mime(String path) {
        String n = path.toLowerCase(Locale.ROOT);
        if (n.endsWith(".mp4") || n.endsWith(".m4v") || n.endsWith(".mov")) return "video/mp4";
        if (n.endsWith(".mkv")) return "video/x-matroska";
        if (n.endsWith(".avi")) return "video/x-msvideo";
        if (n.endsWith(".webm")) return "video/webm";
        if (n.endsWith(".m2ts") || n.endsWith(".ts")) return "video/mp2t";
        if (n.endsWith(".srt")) return "application/x-subrip";
        return "application/octet-stream";
    }

    private void handleStream(Socket client) {
        try {
            Request req = read(client);
            if (req == null) return;
            Uri target = Uri.parse("http://localhost" + req.target);
            if (!"/stream".equals(target.getPath()) || !service.authorized(target.getQueryParameter("token"))) {
                send(client, 401, "text/plain", "Not authorized".getBytes(StandardCharsets.UTF_8));
                return;
            }
            if (!"GET".equals(req.method) && !"HEAD".equals(req.method)) {
                send(client, 405, "text/plain", new byte[0]);
                return;
            }
            String path = SmbRepository.safeRelative(target.getQueryParameter("path"));
            if (!SmbRepository.video(path) && !path.toLowerCase(Locale.ROOT).endsWith(".srt")) {
                send(client, 404, "text/plain", new byte[0]);
                return;
            }
            // Open the SMB file once for both metadata and Range reads, and release it.
            try (SmbFile file = smb.open(path)) {
                long total = file.length();
                long start = 0, end = total - 1;
                boolean ranged = false;
                String range = req.headers.get("range");
                if (range != null && range.startsWith("bytes=")) {
                    ranged = true;
                    String part = range.substring(6).split(",", 2)[0].trim();
                    String[] se = part.split("-", -1);
                    if (se.length != 2) throw new IllegalArgumentException("Invalid Range");
                    if (se[0].isEmpty()) {
                        long suffix = Long.parseLong(se[1]);
                        if (suffix <= 0) throw new IllegalArgumentException("Invalid suffix Range");
                        start = Math.max(0, total - suffix);
                    } else {
                        start = Long.parseLong(se[0]);
                        if (!se[1].isEmpty()) end = Math.min(end, Long.parseLong(se[1]));
                    }
                }
                if (total == 0 || start < 0 || end < start || start >= total) {
                    headers(client.getOutputStream(), 416, "Range Not Satisfiable", "text/plain", 0,
                            "Content-Range: bytes */" + total + "\r\n");
                    return;
                }
                OutputStream out = client.getOutputStream();
                long length = end - start + 1;
                String extra = "Accept-Ranges: bytes\r\n";
                if (ranged) extra += "Content-Range: bytes " + start + "-" + end + "/" + total + "\r\n";
                if ("HEAD".equals(req.method)) {
                    headers(out, ranged ? 206 : 200, ranged ? "Partial Content" : "OK", mime(path), length, extra);
                    return;
                }
                // Do not tell Vimu that a stream is ready before SMB opens successfully.
                try (SmbRandomAccessFile raf = new SmbRandomAccessFile(file, "r")) {
                    raf.seek(start);
                    headers(out, ranged ? 206 : 200, ranged ? "Partial Content" : "OK", mime(path), length, extra);
                    byte[] bytes = new byte[64 * 1024];
                    long remain = length;
                    while (remain > 0 && !Thread.currentThread().isInterrupted()) {
                        int n = raf.read(bytes, 0, (int) Math.min(bytes.length, remain));
                        if (n <= 0) break;
                        out.write(bytes, 0, n);
                        remain -= n;
                    }
                    out.flush();
                }
            }
        } catch (Exception e) {
            // A socket may already be streaming binary data; do not append an HTTP error body.
            android.util.Log.e("VimuDirect", "Range stream failed", e);
            service.setStatus("视频读取失败：" + BridgeService.explain(e));
        }
    }
}
