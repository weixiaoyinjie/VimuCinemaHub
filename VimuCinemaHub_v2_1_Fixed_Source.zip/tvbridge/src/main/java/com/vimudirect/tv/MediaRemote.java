package com.vimudirect.tv;

import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.provider.Settings;
import android.view.KeyEvent;
import android.text.TextUtils;
import org.json.JSONObject;
import java.util.List;

/** Optional system MediaSession controller. Never claims to be a Vimu proprietary control API. */
final class MediaRemote {
    private static final String[] VIMU_PACKAGES = {"net.gtvbox.videoplayer", "net.gtvbox.vimuhd"};
    private static boolean isVimu(String pkg) {
        if (pkg == null) return false;
        for (String p : VIMU_PACKAGES) if (p.equals(pkg)) return true;
        return false;
    }
    private static boolean listenerEnabled(Context context) {
        String s = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(context.getPackageName() + "/");
    }
    private static MediaController session(Context context) {
        if (!listenerEnabled(context)) return null;
        try {
            MediaSessionManager manager = (MediaSessionManager) context.getSystemService(Context.MEDIA_SESSION_SERVICE);
            ComponentName listener = new ComponentName(context, SessionListener.class);
            List<MediaController> sessions = manager.getActiveSessions(listener);
            for (MediaController c : sessions) if (isVimu(c.getPackageName())) return c;
        } catch (Exception ignored) { }
        return null;
    }
    static JSONObject state(Context c) throws Exception {
        JSONObject j = new JSONObject();
        boolean enabled = listenerEnabled(c);
        j.put("permission", enabled);
        MediaController ctl = session(c);
        j.put("session", ctl != null);
        j.put("canPlayPause", false);
        j.put("canSeek", false);
        j.put("canNext", false);
        j.put("canPrev", false);
        j.put("playing", false);
        j.put("position", 0);
        j.put("duration", 0);
        if (ctl != null) {
            PlaybackState st = ctl.getPlaybackState();
            MediaMetadata meta = ctl.getMetadata();
            if (st != null) {
                long actions = st.getActions();
                j.put("canPlayPause", (actions & (PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE)) != 0);
                j.put("canSeek", (actions & PlaybackState.ACTION_SEEK_TO) != 0);
                j.put("canNext", (actions & PlaybackState.ACTION_SKIP_TO_NEXT) != 0);
                j.put("canPrev", (actions & PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0);
                j.put("playing", st.getState() == PlaybackState.STATE_PLAYING);
                long pos = Math.max(0, st.getPosition());
                if (st.getState() == PlaybackState.STATE_PLAYING && st.getLastPositionUpdateTime() > 0) {
                    pos += (long) ((android.os.SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed());
                }
                j.put("position", pos);
            }
            if (meta != null) {
                j.put("duration", Math.max(0, meta.getLong(MediaMetadata.METADATA_KEY_DURATION)));
                CharSequence title = meta.getText(MediaMetadata.METADATA_KEY_TITLE);
                if (title != null) j.put("mediaTitle", title.toString());
            }
        }
        AudioManager a = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        j.put("volume", a.getStreamVolume(AudioManager.STREAM_MUSIC));
        j.put("volumeMax", a.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        j.put("fixedVolume", a.isVolumeFixed());
        return j;
    }
    static JSONObject command(Context context, String action, long absoluteMs) throws Exception {
        if ("testPlayPause".equals(action)) {
            AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
            audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
            return new JSONObject().put("ok", true).put("message", "已向系统发送媒体播放/暂停键；只有当前播放器注册并接收媒体按键时才有效");
        }
        if ("volumeUp".equals(action) || "volumeDown".equals(action)) {
            AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (audio.isVolumeFixed()) return new JSONObject().put("ok", false).put("message", "电视的系统音量为固定输出，请使用电视/音响遥控器调节");
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    "volumeUp".equals(action) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
            return new JSONObject().put("ok", true).put("message", "已向系统发送音量调整");
        }
        MediaController c = session(context);
        if (c == null) return new JSONObject().put("ok", false).put("message", "没有发现 Vimu 媒体会话：请在电视授权通知使用权，并确认 Vimu 播放时公布了 MediaSession");
        PlaybackState st = c.getPlaybackState();
        if (st == null) return new JSONObject().put("ok", false).put("message", "Vimu 没有提供可控制的播放状态");
        long flags = st.getActions();
        MediaController.TransportControls t = c.getTransportControls();
        switch (action) {
            case "toggle":
                if (st.getState() == PlaybackState.STATE_PLAYING && (flags & (PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE)) != 0) t.pause();
                else if ((flags & (PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PLAY_PAUSE)) != 0) t.play();
                else return new JSONObject().put("ok", false).put("message", "当前媒体会话不支持暂停/播放");
                break;
            case "next":
                if ((flags & PlaybackState.ACTION_SKIP_TO_NEXT) == 0) return unsupported();
                t.skipToNext(); break;
            case "prev":
                if ((flags & PlaybackState.ACTION_SKIP_TO_PREVIOUS) == 0) return unsupported();
                t.skipToPrevious(); break;
            case "seekTo":
                if ((flags & PlaybackState.ACTION_SEEK_TO) == 0) return unsupported();
                long ms = Math.max(0, absoluteMs);
                MediaMetadata md = c.getMetadata();
                if (md != null && md.getLong(MediaMetadata.METADATA_KEY_DURATION) > 0)
                    ms = Math.min(ms, md.getLong(MediaMetadata.METADATA_KEY_DURATION));
                t.seekTo(ms); break;
            case "back30":
            case "forward30":
                if ((flags & PlaybackState.ACTION_SEEK_TO) == 0) return unsupported();
                long move = "back30".equals(action) ? -30000L : 30000L;
                long target = Math.max(0, st.getPosition() + move);
                MediaMetadata meta = c.getMetadata();
                if (meta != null) {
                    long duration = meta.getLong(MediaMetadata.METADATA_KEY_DURATION);
                    if (duration > 0) target = Math.min(target, duration);
                }
                t.seekTo(target); break;
            default: return new JSONObject().put("ok", false).put("message", "不支持的控制命令");
        }
        return new JSONObject().put("ok", true).put("message", "控制已发送到 Vimu MediaSession（是否执行取决于播放器）");
    }
    private static JSONObject unsupported() throws Exception {
        return new JSONObject().put("ok", false).put("message", "Vimu 当前没有公开此媒体会话控制能力");
    }
}
