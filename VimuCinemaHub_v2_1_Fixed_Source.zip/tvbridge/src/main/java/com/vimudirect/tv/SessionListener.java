package com.vimudirect.tv;
import android.service.notification.NotificationListenerService;
/** Android only grants access to other apps' MediaSessions after user explicitly enables this service. */
public final class SessionListener extends NotificationListenerService { }
