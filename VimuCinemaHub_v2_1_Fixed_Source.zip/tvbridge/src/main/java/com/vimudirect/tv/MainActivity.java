package com.vimudirect.tv;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;

public final class MainActivity extends Activity {
    private TextView connection;
    private TextView state;
    private boolean visible = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() { if (visible) { refresh(); handler.postDelayed(this, 1500); } }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(8, 18, 35));
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setPadding(dp(40), dp(28), dp(40), dp(28));
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        setContentView(scroll);
        addLabel(content, "VIMU DIRECT / TV BRIDGE", 26, Color.WHITE, true);
        addLabel(content, "无需 Kodi · 手机遥控本机 Vimu · SMB 文件由电视直读", 16, 0xff9eb1cf, false);
        addLabel(content, "设备局域网地址", 18, Color.WHITE, true);
        connection = addLabel(content, "正在检测……", 21, 0xff54e0d5, true);
        addLabel(content, "请在 Fold6 App 输入上面的 IP，再输入以下配对密钥：", 15, 0xffcad5e7, false);
        addLabel(content, BridgeService.token(this), 28, 0xffffd579, true);
        state = addLabel(content, "服务尚未启动", 18, 0xffcad5e7, false);
        action(content, "① 启动电视桥接服务", () -> {
            try { startForegroundService(new Intent(this, BridgeService.class)); refresh(); }
            catch (Exception e) { state.setText("启动失败：" + e.getMessage()); }
        });
        action(content, "② 播放手机发来的待处理影片", () -> {
            if (BridgeService.instance == null) state.setText("请先启动服务");
            else BridgeService.instance.launchPending();
        });
        action(content, "③ 授权媒体会话控制（可选）", () -> {
            try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
            catch (Exception e) { state.setText("本电视暂不提供该授权页面：" + e.getMessage()); }
        });
        addLabel(content, "只有 Vimu 自身公布 MediaSession 时，手机暂停、进度条、前后跳转才可控制。电视授权通知使用权并不保证 Vimu 提供会话。", 14, 0xff9eb1cf, false);
        action(content, "④ 打开已安装的 Vimu", () -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("net.gtvbox.videoplayer");
            if (intent == null) intent = getPackageManager().getLaunchIntentForPackage("net.gtvbox.vimuhd");
            if (intent == null) state.setText("未检测到官方 Vimu 包 net.gtvbox.videoplayer，请检查安装版本");
            else startActivity(intent);
        });
        action(content, "停止桥接服务", () -> { stopService(new Intent(this, BridgeService.class)); refresh(); });
        addLabel(content, "建议首次测试时保持本页面在电视上，手机选片即可直接启动。若 Vimu 已处前台、系统阻止后台再次唤起，请返回这里点击②，或打开通知。", 14, 0xff9eb1cf, false);
        addLabel(content, "安全提示：只在可信家庭局域网使用。配对密钥等同远程控制权限，请不要发给他人。", 13, 0xffa7b5c8, false);
    }
    @Override protected void onResume() { super.onResume(); visible = true; BridgeService.visibleActivity = new java.lang.ref.WeakReference<>(this); handler.post(refreshLoop); }
    @Override protected void onPause() { visible = false; handler.removeCallbacks(refreshLoop); BridgeService.visibleActivity = new java.lang.ref.WeakReference<>(null); super.onPause(); }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if ("com.vimudirect.tv.PLAY_PENDING".equals(intent.getAction()) && BridgeService.instance != null) {
            handler.postDelayed(() -> BridgeService.instance.launchPending(), 250);
        }
    }
    boolean isActuallyVisible() { return visible; }
    void refresh() {
        connection.setText(localIps() + "   ·   控制端口 8765");
        BridgeService s = BridgeService.instance;
        state.setText(s == null ? "状态：未启动" : "状态：" + s.getStatus() + "\n待播放：" + s.getPendingTitle());
    }
    private String localIps() {
        StringBuilder b = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        if (b.length() > 0) b.append(" / ");
                        b.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) {}
        return b.length() == 0 ? "IP 暂未获取（请检查网络）" : b.toString();
    }
    private TextView addLabel(LinearLayout root, String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(8), 0, dp(9));
        root.addView(v);
        return v;
    }
    private void action(LinearLayout root, String text, Runnable run) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff205c85));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.setMargins(0, dp(7), 0, dp(7));
        root.addView(b, lp);
        b.setOnClickListener(v -> run.run());
    }
    private int dp(int d) { return (int) (getResources().getDisplayMetrics().density * d + .5f); }
}
